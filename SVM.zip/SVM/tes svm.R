
ccr <- read.csv("~/breast-cancer.data", header=FALSE)
head(ccr)
colnames(ccr)<- c("classifier", "age", "menopause", "tumor-size", "inv-nodes", "node-caps", "deg-malig", "breast", "breast-quad", "irradiat")
str(ccr)
ccr$`deg-malig` <- as.factor(ccr$`deg-malig`)
ccr$`deg-malig` <- as.integer(ccr$`deg-malig`)

#split data
set.seed(69)
sample <- sample(nrow(ccr), 0.8*nrow(ccr))
train <- ccr[sample,]
test <- ccr[-sample,]

library(e1071)
ls('package:e1071')
svmku <- svm(classifier~., train, type ="C-classification", kernel = "radial")
svmku

hasil5 <- predict(svmku, test)

library(caret)
confusionMatrix(hasil5, test$classifier)