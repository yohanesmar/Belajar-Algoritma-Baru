mtcars <- as.data.frame(mtcars)
library(dplyr)
library(tibble)
pcars <- rownames_to_column(mtcars, var = "car") 

set.seed(123)
samplecars <- sample(nrow(pcars), 25)
traincars <- pcars[samplecars,]
testcars <- pcars[-samplecars,]
#zcars <- column_to_rownames(pcars, "car")

modelcars <- glm(vs~., data = traincars[-c(1)], family = binomial) 
# ingat, (Y~.-c)  berarti Y~(p+q+r)-r, dalam hal ini r sudah di define dalam model

predicars <- predict(modelcars, testcars)
predicars <- ifelse(predicars >0, 1, 0)


#tes akurasi
mean(predicars == testcars$vs)
#[1] 0.8571429